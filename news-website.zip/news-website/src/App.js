import logo from './logo.svg';
import './App.css';
import Newsapp from './Components/Newsapp';


function App() {
  return (
    <Newsapp/>
  );
} 

export default App;
